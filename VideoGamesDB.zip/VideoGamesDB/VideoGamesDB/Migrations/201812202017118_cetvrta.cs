namespace VideoGamesDB.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class cetvrta : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.VideoGames", "GameName", c => c.String());
            DropColumn("dbo.VideoGames", "Name");
        }
        
        public override void Down()
        {
            AddColumn("dbo.VideoGames", "Name", c => c.String());
            DropColumn("dbo.VideoGames", "GameName");
        }
    }
}
