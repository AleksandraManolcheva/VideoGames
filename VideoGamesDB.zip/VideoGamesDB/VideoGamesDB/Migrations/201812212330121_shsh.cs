namespace VideoGamesDB.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class shsh : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Stores",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            AddColumn("dbo.VideoGames", "Store_Id", c => c.Int());
            CreateIndex("dbo.VideoGames", "Store_Id");
            AddForeignKey("dbo.VideoGames", "Store_Id", "dbo.Stores", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.VideoGames", "Store_Id", "dbo.Stores");
            DropIndex("dbo.VideoGames", new[] { "Store_Id" });
            DropColumn("dbo.VideoGames", "Store_Id");
            DropTable("dbo.Stores");
        }
    }
}
