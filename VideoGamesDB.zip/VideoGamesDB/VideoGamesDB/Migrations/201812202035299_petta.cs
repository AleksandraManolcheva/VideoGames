namespace VideoGamesDB.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class petta : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.VideoGames", "Name", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.VideoGames", "Name");
        }
    }
}
