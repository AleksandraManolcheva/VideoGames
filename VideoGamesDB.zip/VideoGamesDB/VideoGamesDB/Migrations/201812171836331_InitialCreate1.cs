namespace VideoGamesDB.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate1 : DbMigration
    {
        public override void Up()
        {
            DropPrimaryKey("dbo.VideoGames");
            AddColumn("dbo.VideoGames", "Id", c => c.Int(nullable: false, identity: true));
            AlterColumn("dbo.VideoGames", "Name", c => c.String());
            AddPrimaryKey("dbo.VideoGames", "Id");
        }
        
        public override void Down()
        {
            DropPrimaryKey("dbo.VideoGames");
            AlterColumn("dbo.VideoGames", "Name", c => c.String(nullable: false, maxLength: 128));
            DropColumn("dbo.VideoGames", "Id");
            AddPrimaryKey("dbo.VideoGames", "Name");
        }
    }
}
