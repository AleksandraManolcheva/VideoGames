﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(VideoGamesDB.Startup))]
namespace VideoGamesDB
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
