﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoGamesDB.Models
{
    public class AddToStoreModel
    {
        public int storeId { get; set; }
        public int gameId { get; set; }
        public List<VideoGame> videogames { get; set; }
        public AddToStoreModel()
            {
            videogames = new List<VideoGame>();
            }
    }
}