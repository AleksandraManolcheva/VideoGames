﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoGamesDB.Models
{
    public class Store
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public List<VideoGame> videogames { get; set; } 
        Store()
        {
            videogames = new List<VideoGame>();
        }
    }
}